#load and summarise the MNIST dataset
from keras.datasets import mnist
#load dataset
(train_images, train_labels), (test_images, test_labels) = mnist.load_data()
#summarise dataset shape
print('Train', train_images.shape, train_labels.shape)
print('Test', (test_images.shape, test_labels.shape))
#summarise pixel values
print('Train', train_images.min(), train_images.max(), train_images.mean(), train_images.std())
print('Train', test_images.min(), test_images.max(), test_images.mean(), test_images.std())
