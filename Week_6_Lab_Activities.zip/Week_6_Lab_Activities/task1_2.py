#example of converting an image with the Keras API
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.preprocessing.image import array_to_img
#load the image
img_path = '/content/drive/MyDrive/2026_Uni/ST1/Weekly_Lab_Activities_Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG'
img = load_img(img_path)
print(type(img))
#convert to numpy array
img_array = img_to_array(img)
print(img_array.dtype)
print(img_array.shape)
#convert back to image
img_pil = array_to_img(img_array)
print(type(img))
